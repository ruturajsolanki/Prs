-- Users table
CREATE TABLE IF NOT EXISTS users (
    id INT AUTO_INCREMENT PRIMARY KEY,
    name VARCHAR(100) NOT NULL,
    email VARCHAR(100) UNIQUE NOT NULL,
    password VARCHAR(100) NOT NULL,
    role VARCHAR(20) NOT NULL,
    status VARCHAR(20) DEFAULT 'ACTIVE'
);

-- Reviews table
CREATE TABLE IF NOT EXISTS reviews (
    id INT AUTO_INCREMENT PRIMARY KEY,
    reviewee_id INT NOT NULL,
    type VARCHAR(20) NOT NULL,
    deadline DATE NOT NULL,
    comments TEXT,
    status VARCHAR(20) NOT NULL DEFAULT 'PENDING',
    created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
    FOREIGN KEY (reviewee_id) REFERENCES users(id)
);

-- Insert test users
INSERT INTO users (name, email, password, role, status) VALUES
('John Developer', 'john@example.com', 'test123', 'SSE', 'ACTIVE'),
('Jane Team Lead', 'jane@example.com', 'test123', 'TeamLead', 'ACTIVE'),
('Bob Junior', 'bob@example.com', 'test123', 'JSE', 'ACTIVE'),
('Alice Intern', 'alice@example.com', 'test123', 'Intern', 'ACTIVE')
ON DUPLICATE KEY UPDATE id=id; 