package com.peerreview.dao;

import java.sql.Connection;
import java.sql.Date;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;
import java.util.logging.Level;
import java.util.logging.Logger;

import com.peerreview.model.Review;
import com.peerreview.util.DBConnection;
import com.peerreview.util.DatabaseUtil;

public class ReviewDAO {
    private static final Logger LOGGER = Logger.getLogger(ReviewDAO.class.getName());
    private final UserDAO userDAO = new UserDAO();

    public boolean createReviewWithAssignments(Review review, List<Integer> reviewerIds) {
        Connection conn = null;
        try {
            conn = DBConnection.getConnection();
            conn.setAutoCommit(false);

            // Insert review
            String reviewSql = "INSERT INTO reviews (reviewee_id, type, deadline, comments, status) VALUES (?, ?, ?, ?, ?)";
            try (PreparedStatement stmt = conn.prepareStatement(reviewSql, Statement.RETURN_GENERATED_KEYS)) {
                stmt.setInt(1, review.getReviewee().getId());
                stmt.setString(2, review.getType().toString());
                stmt.setDate(3, review.getDeadline());
                stmt.setString(4, review.getComments());
                stmt.setString(5, review.getStatus().toString());

                int affectedRows = stmt.executeUpdate();
                if (affectedRows == 0) {
                    throw new SQLException("Creating review failed, no rows affected.");
                }

                try (ResultSet generatedKeys = stmt.getGeneratedKeys()) {
                    if (generatedKeys.next()) {
                        review.setId(generatedKeys.getInt(1));
                    } else {
                        throw new SQLException("Creating review failed, no ID obtained.");
                    }
                }
            }

            // Insert review assignments
            String assignmentSql = "INSERT INTO review_assignments (review_id, reviewer_id) VALUES (?, ?)";
            try (PreparedStatement stmt = conn.prepareStatement(assignmentSql)) {
                for (Integer reviewerId : reviewerIds) {
                    stmt.setInt(1, review.getId());
                    stmt.setInt(2, reviewerId);
                    stmt.addBatch();
                }
                stmt.executeBatch();
            }

            conn.commit();
            return true;

        } catch (SQLException e) {
            LOGGER.log(Level.SEVERE, "Error creating review with assignments", e);
            if (conn != null) {
                try {
                    conn.rollback();
                } catch (SQLException ex) {
                    LOGGER.log(Level.SEVERE, "Error rolling back transaction", ex);
                }
            }
            return false;
        } finally {
            if (conn != null) {
                try {
                    conn.setAutoCommit(true);
                    conn.close();
                } catch (SQLException e) {
                    LOGGER.log(Level.WARNING, "Error closing connection", e);
                }
            }
        }
    }

    public int countTotalReviewsByManager(int managerId) {
        String sql = "SELECT COUNT(*) FROM reviews WHERE manager_id = ?";
        try (Connection conn = DBConnection.getConnection();
             PreparedStatement stmt = conn.prepareStatement(sql)) {
            
            stmt.setInt(1, managerId);
            ResultSet rs = stmt.executeQuery();
            
            if (rs.next()) {
                return rs.getInt(1);
            }
        } catch (SQLException e) {
            LOGGER.log(Level.SEVERE, "Error counting total reviews", e);
        }
        return 0;
    }

    public int countPendingReviewsByManager(int managerId) {
        String sql = "SELECT COUNT(*) FROM reviews WHERE manager_id = ? AND status IN ('Pending', 'InProgress')";
        try (Connection conn = DBConnection.getConnection();
             PreparedStatement stmt = conn.prepareStatement(sql)) {
            
            stmt.setInt(1, managerId);
            ResultSet rs = stmt.executeQuery();
            
            if (rs.next()) {
                return rs.getInt(1);
            }
        } catch (SQLException e) {
            LOGGER.log(Level.SEVERE, "Error counting pending reviews", e);
        }
        return 0;
    }

    public int countCompletedReviewsByManager(int managerId) {
        String sql = "SELECT COUNT(*) FROM reviews WHERE manager_id = ? AND status = 'Completed'";
        try (Connection conn = DBConnection.getConnection();
             PreparedStatement stmt = conn.prepareStatement(sql)) {
            
            stmt.setInt(1, managerId);
            ResultSet rs = stmt.executeQuery();
            
            if (rs.next()) {
                return rs.getInt(1);
            }
        } catch (SQLException e) {
            LOGGER.log(Level.SEVERE, "Error counting completed reviews", e);
        }
        return 0;
    }

    public List<Review> findRecentReviewsByManager(int managerId, int limit) {
        List<Review> reviews = new ArrayList<>();
        String sql = "SELECT r.*, u.name as reviewee_name " +
                    "FROM reviews r " +
                    "JOIN users u ON r.reviewee_id = u.id " +
                    "WHERE r.manager_id = ? " +
                    "ORDER BY r.assigned_date DESC LIMIT ?";
                    
        try (Connection conn = DBConnection.getConnection();
             PreparedStatement stmt = conn.prepareStatement(sql)) {
            
            stmt.setInt(1, managerId);
            stmt.setInt(2, limit);
            ResultSet rs = stmt.executeQuery();
            
            while (rs.next()) {
                Review review = mapResultSetToReview(rs);
                review.setRevieweeName(rs.getString("reviewee_name"));
                reviews.add(review);
            }
        } catch (SQLException e) {
            LOGGER.log(Level.SEVERE, "Error finding recent reviews", e);
        }
        return reviews;
    }

    public List<Map<String, Object>> getCalendarEventsByManager(int managerId) {
        List<Map<String, Object>> events = new ArrayList<>();
        String sql = "SELECT r.*, u.name as reviewee_name " +
                    "FROM reviews r " +
                    "JOIN users u ON r.reviewee_id = u.id " +
                    "WHERE r.manager_id = ? AND r.status != 'Revoked'";
                    
        try (Connection conn = DBConnection.getConnection();
             PreparedStatement stmt = conn.prepareStatement(sql)) {
            
            stmt.setInt(1, managerId);
            ResultSet rs = stmt.executeQuery();
            
            while (rs.next()) {
                Map<String, Object> event = new HashMap<>();
                event.put("id", rs.getInt("id"));
                event.put("title", rs.getString("reviewee_name") + "'s " + rs.getString("type") + " Review");
                event.put("start", rs.getDate("deadline").toString());
                
                // Set event color based on status
                String status = rs.getString("status");
                String color;
                switch (status) {
                    case "Completed":
                        color = "#2ecc71"; // Green
                        break;
                    case "InProgress":
                        color = "#f1c40f"; // Yellow
                        break;
                    default:
                        color = "#e74c3c"; // Red for Pending
                }
                event.put("backgroundColor", color);
                
                events.add(event);
            }
        } catch (SQLException e) {
            LOGGER.log(Level.SEVERE, "Error getting calendar events", e);
        }
        return events;
    }

    public Review findById(int reviewId) {
        String sql = "SELECT * FROM reviews WHERE id = ?";
        try (Connection conn = DBConnection.getConnection();
             PreparedStatement stmt = conn.prepareStatement(sql)) {
            
            stmt.setInt(1, reviewId);
            ResultSet rs = stmt.executeQuery();
            
            if (rs.next()) {
                Review review = new Review();
                review.setId(rs.getInt("id"));
                review.setReviewee(userDAO.getUserById(rs.getInt("reviewee_id")));
                review.setType(Review.ReviewType.valueOf(rs.getString("type")));
                review.setStatus(Review.ReviewStatus.valueOf(rs.getString("status")));
                review.setDeadline(rs.getDate("deadline"));
                review.setCreatedAt(rs.getTimestamp("created_at"));
                return review;
            }
        } catch (SQLException e) {
            LOGGER.log(Level.SEVERE, "Error finding review by ID", e);
        }
        return null;
    }

    public boolean isReviewerAssigned(int reviewId, int reviewerId) {
        String sql = "SELECT COUNT(*) FROM review_assignments WHERE review_id = ? AND reviewer_id = ?";
        try (Connection conn = DBConnection.getConnection();
             PreparedStatement stmt = conn.prepareStatement(sql)) {
            
            stmt.setInt(1, reviewId);
            stmt.setInt(2, reviewerId);
            ResultSet rs = stmt.executeQuery();
            
            if (rs.next()) {
                return rs.getInt(1) > 0;
            }
        } catch (SQLException e) {
            LOGGER.log(Level.SEVERE, "Error checking reviewer assignment", e);
        }
        return false;
    }

    public long calculateDaysRemaining(int reviewId) {
        String sql = "SELECT deadline FROM reviews WHERE id = ?";
        try (Connection conn = DBConnection.getConnection();
             PreparedStatement stmt = conn.prepareStatement(sql)) {
            
            stmt.setInt(1, reviewId);
            ResultSet rs = stmt.executeQuery();
            
            if (rs.next()) {
                Date deadline = rs.getDate("deadline");
                long diff = deadline.getTime() - System.currentTimeMillis();
                return Math.max(0, diff / (1000 * 60 * 60 * 24));
            }
        } catch (SQLException e) {
            LOGGER.log(Level.SEVERE, "Error calculating days remaining", e);
        }
        return 0;
    }

    public boolean submitKRAForm(int reviewId, int reviewerId, Map<String, Object> kraData) {
        String sql = "INSERT INTO kra_reviews (review_id, reviewer_id, technical_1, technical_2, " +
                    "technical_comments, communication_1, communication_2, communication_comments, " +
                    "overall_comments) VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?)";
        
        try (Connection conn = DBConnection.getConnection();
             PreparedStatement stmt = conn.prepareStatement(sql)) {
            
            stmt.setInt(1, reviewId);
            stmt.setInt(2, reviewerId);
            stmt.setInt(3, (Integer) kraData.get("technical_1"));
            stmt.setInt(4, (Integer) kraData.get("technical_2"));
            stmt.setString(5, (String) kraData.get("technical_comments"));
            stmt.setInt(6, (Integer) kraData.get("communication_1"));
            stmt.setInt(7, (Integer) kraData.get("communication_2"));
            stmt.setString(8, (String) kraData.get("communication_comments"));
            stmt.setString(9, (String) kraData.get("overall_comments"));
            
            return stmt.executeUpdate() > 0;
        } catch (SQLException e) {
            LOGGER.log(Level.SEVERE, "Error submitting KRA form", e);
            return false;
        }
    }

    public boolean haveAllReviewersSubmitted(int reviewId) {
        String sql = "SELECT COUNT(*) = (SELECT COUNT(*) FROM review_assignments WHERE review_id = ?) " +
                    "FROM kra_reviews WHERE review_id = ?";
        
        try (Connection conn = DBConnection.getConnection();
             PreparedStatement stmt = conn.prepareStatement(sql)) {
            
            stmt.setInt(1, reviewId);
            stmt.setInt(2, reviewId);
            ResultSet rs = stmt.executeQuery();
            
            if (rs.next()) {
                return rs.getBoolean(1);
            }
        } catch (SQLException e) {
            LOGGER.log(Level.SEVERE, "Error checking if all reviewers submitted", e);
        }
        return false;
    }

    public boolean updateReviewStatus(int reviewId, Review.ReviewStatus status) {
        String sql = "UPDATE reviews SET status = ? WHERE id = ?";
        try (Connection conn = DBConnection.getConnection();
             PreparedStatement stmt = conn.prepareStatement(sql)) {
            
            stmt.setString(1, status.toString());
            stmt.setInt(2, reviewId);
            
            return stmt.executeUpdate() > 0;
        } catch (SQLException e) {
            LOGGER.log(Level.SEVERE, "Error updating review status", e);
            return false;
        }
    }

    public boolean submitFeedbackForm(int reviewId, int reviewerId, Map<String, String> feedbackData) {
        String sql = "INSERT INTO feedback_form (review_id, reviewer_id, strengths, improvements, additional_comments) " +
                    "VALUES (?, ?, ?, ?, ?)";
        
        try (Connection conn = DBConnection.getConnection();
             PreparedStatement stmt = conn.prepareStatement(sql)) {
            
            stmt.setInt(1, reviewId);
            stmt.setInt(2, reviewerId);
            stmt.setString(3, feedbackData.get("strengths"));
            stmt.setString(4, feedbackData.get("improvements"));
            stmt.setString(5, feedbackData.get("additional_comments"));
            
            return stmt.executeUpdate() > 0;
        } catch (SQLException e) {
            LOGGER.log(Level.SEVERE, "Error submitting feedback form", e);
            return false;
        }
    }

    public int countTotalReviewsByReviewer(int reviewerId) {
        String sql = "SELECT COUNT(*) FROM review_assignments WHERE reviewer_id = ?";
        try (Connection conn = DBConnection.getConnection();
             PreparedStatement stmt = conn.prepareStatement(sql)) {
            
            stmt.setInt(1, reviewerId);
            ResultSet rs = stmt.executeQuery();
            
            if (rs.next()) {
                return rs.getInt(1);
            }
        } catch (SQLException e) {
            LOGGER.log(Level.SEVERE, "Error counting total reviews by reviewer", e);
        }
        return 0;
    }

    public int countPendingReviewsByReviewer(int reviewerId) {
        String sql = "SELECT COUNT(*) FROM review_assignments ra " +
                    "JOIN reviews r ON ra.review_id = r.id " +
                    "WHERE ra.reviewer_id = ? AND r.status IN ('Pending', 'InProgress')";
        try (Connection conn = DBConnection.getConnection();
             PreparedStatement stmt = conn.prepareStatement(sql)) {
            
            stmt.setInt(1, reviewerId);
            ResultSet rs = stmt.executeQuery();
            
            if (rs.next()) {
                return rs.getInt(1);
            }
        } catch (SQLException e) {
            LOGGER.log(Level.SEVERE, "Error counting pending reviews by reviewer", e);
        }
        return 0;
    }

    public int countCompletedReviewsByReviewer(int reviewerId) {
        String sql = "SELECT COUNT(*) FROM review_assignments ra " +
                    "JOIN reviews r ON ra.review_id = r.id " +
                    "WHERE ra.reviewer_id = ? AND r.status = 'Completed'";
        try (Connection conn = DBConnection.getConnection();
             PreparedStatement stmt = conn.prepareStatement(sql)) {
            
            stmt.setInt(1, reviewerId);
            ResultSet rs = stmt.executeQuery();
            
            if (rs.next()) {
                return rs.getInt(1);
            }
        } catch (SQLException e) {
            LOGGER.log(Level.SEVERE, "Error counting completed reviews by reviewer", e);
        }
        return 0;
    }

    public List<Review> findAssignedReviews(int reviewerId) {
        List<Review> reviews = new ArrayList<>();
        String sql = "SELECT r.*, u.name as reviewee_name, " +
                    "DATEDIFF(r.deadline, CURRENT_DATE) as days_remaining " +
                    "FROM reviews r " +
                    "JOIN review_assignments ra ON r.id = ra.review_id " +
                    "JOIN users u ON r.reviewee_id = u.id " +
                    "WHERE ra.reviewer_id = ? AND r.status != 'Revoked' " +
                    "ORDER BY r.deadline ASC";
                    
        try (Connection conn = DBConnection.getConnection();
             PreparedStatement stmt = conn.prepareStatement(sql)) {
            
            stmt.setInt(1, reviewerId);
            ResultSet rs = stmt.executeQuery();
            
            while (rs.next()) {
                Review review = mapResultSetToReview(rs);
                review.setRevieweeName(rs.getString("reviewee_name"));
                review.setDaysRemaining(rs.getInt("days_remaining"));
                reviews.add(review);
            }
        } catch (SQLException e) {
            LOGGER.log(Level.SEVERE, "Error finding assigned reviews", e);
        }
        return reviews;
    }

    public List<Map<String, String>> getRecentActivityByReviewer(int reviewerId, int limit) {
        List<Map<String, String>> activities = new ArrayList<>();
        String sql = "SELECT r.type, u.name as reviewee_name, r.status, r.assigned_date " +
                    "FROM reviews r " +
                    "JOIN review_assignments ra ON r.id = ra.review_id " +
                    "JOIN users u ON r.reviewee_id = u.id " +
                    "WHERE ra.reviewer_id = ? " +
                    "ORDER BY r.assigned_date DESC LIMIT ?";
                    
        try (Connection conn = DBConnection.getConnection();
             PreparedStatement stmt = conn.prepareStatement(sql)) {
            
            stmt.setInt(1, reviewerId);
            stmt.setInt(2, limit);
            ResultSet rs = stmt.executeQuery();
            
            while (rs.next()) {
                Map<String, String> activity = new HashMap<>();
                String type = rs.getString("type");
                String revieweeName = rs.getString("reviewee_name");
                String status = rs.getString("status");
                String date = rs.getTimestamp("assigned_date").toString();
                
                String message = String.format("%s review for %s - %s", type, revieweeName, status);
                activity.put("message", message);
                activity.put("date", date);
                
                activities.add(activity);
            }
        } catch (SQLException e) {
            LOGGER.log(Level.SEVERE, "Error getting recent activity", e);
        }
        return activities;
    }

    public Map<String, Double> getAverageScores(int employeeId, int months) {
        Map<String, Double> scores = new HashMap<>();
        String sql = "SELECT AVG(technical_score) as technical, AVG(communication_score) as communication " +
                    "FROM reviews WHERE reviewee_id = ? AND created_at >= DATEADD('MONTH', -?, CURRENT_TIMESTAMP) " +
                    "AND status = 'Completed'";
        
        try (Connection conn = DBConnection.getConnection();
             PreparedStatement stmt = conn.prepareStatement(sql)) {
            
            stmt.setInt(1, employeeId);
            stmt.setInt(2, months);
            
            try (ResultSet rs = stmt.executeQuery()) {
                if (rs.next()) {
                    scores.put("technical", rs.getDouble("technical"));
                    scores.put("communication", rs.getDouble("communication"));
                }
            }
        } catch (SQLException e) {
            LOGGER.log(Level.SEVERE, "Error getting average scores for employee " + employeeId, e);
        }
        return scores;
    }

    public Map<String, Double> getScoreTrends(int employeeId, int months) {
        Map<String, Double> trends = new HashMap<>();
        String sql = "SELECT " +
                    "(SELECT AVG(technical_score) FROM reviews WHERE reviewee_id = ? " +
                    "AND created_at >= DATEADD('MONTH', -?, CURRENT_TIMESTAMP)) - " +
                    "(SELECT AVG(technical_score) FROM reviews WHERE reviewee_id = ? " +
                    "AND created_at >= DATEADD('MONTH', -?, CURRENT_TIMESTAMP) " +
                    "AND created_at < DATEADD('MONTH', -?, CURRENT_TIMESTAMP)) as technical_trend, " +
                    "(SELECT AVG(communication_score) FROM reviews WHERE reviewee_id = ? " +
                    "AND created_at >= DATEADD('MONTH', -?, CURRENT_TIMESTAMP)) - " +
                    "(SELECT AVG(communication_score) FROM reviews WHERE reviewee_id = ? " +
                    "AND created_at >= DATEADD('MONTH', -?, CURRENT_TIMESTAMP) " +
                    "AND created_at < DATEADD('MONTH', -?, CURRENT_TIMESTAMP)) as communication_trend " +
                    "FROM dual";
        
        try (Connection conn = DBConnection.getConnection();
             PreparedStatement stmt = conn.prepareStatement(sql)) {
            
            stmt.setInt(1, employeeId);
            stmt.setInt(2, months);
            stmt.setInt(3, employeeId);
            stmt.setInt(4, months * 2);
            stmt.setInt(5, employeeId);
            stmt.setInt(6, employeeId);
            stmt.setInt(7, months);
            stmt.setInt(8, employeeId);
            stmt.setInt(9, months * 2);
            stmt.setInt(10, months);
            
            try (ResultSet rs = stmt.executeQuery()) {
                if (rs.next()) {
                    trends.put("technical", rs.getDouble("technical_trend"));
                    trends.put("communication", rs.getDouble("communication_trend"));
                }
            }
        } catch (SQLException e) {
            LOGGER.log(Level.SEVERE, "Error getting score trends for employee " + employeeId, e);
        }
        return trends;
    }

    public int countCompletedReviewsByReviewee(int revieweeId) {
        String sql = "SELECT COUNT(*) FROM reviews WHERE reviewee_id = ? AND status = 'Completed'";
        try (Connection conn = DBConnection.getConnection();
             PreparedStatement stmt = conn.prepareStatement(sql)) {
            
            stmt.setInt(1, revieweeId);
            try (ResultSet rs = stmt.executeQuery()) {
                if (rs.next()) {
                    return rs.getInt(1);
                }
            }
        } catch (SQLException e) {
            LOGGER.log(Level.SEVERE, "Error counting completed reviews for reviewee " + revieweeId, e);
        }
        return 0;
    }

    public int countPendingReviewsByReviewee(int revieweeId) {
        String sql = "SELECT COUNT(*) FROM reviews WHERE reviewee_id = ? AND status = 'Pending'";
        try (Connection conn = DBConnection.getConnection();
             PreparedStatement stmt = conn.prepareStatement(sql)) {
            
            stmt.setInt(1, revieweeId);
            try (ResultSet rs = stmt.executeQuery()) {
                if (rs.next()) {
                    return rs.getInt(1);
                }
            }
        } catch (SQLException e) {
            LOGGER.log(Level.SEVERE, "Error counting pending reviews for reviewee " + revieweeId, e);
        }
        return 0;
    }

    public Map<String, Object> getPerformanceTrendData(int employeeId, int months) {
        Map<String, Object> trendData = new HashMap<>();
        String sql = "SELECT DATE_FORMAT(created_at, '%Y-%m') as month, " +
                    "AVG(technical_score) as technical_avg, " +
                    "AVG(communication_score) as communication_avg " +
                    "FROM reviews WHERE reviewee_id = ? " +
                    "AND created_at >= DATEADD('MONTH', -?, CURRENT_TIMESTAMP) " +
                    "AND status = 'Completed' " +
                    "GROUP BY DATE_FORMAT(created_at, '%Y-%m') " +
                    "ORDER BY month";
        
        List<String> labels = new ArrayList<>();
        List<Double> technical = new ArrayList<>();
        List<Double> communication = new ArrayList<>();
        
        try (Connection conn = DBConnection.getConnection();
             PreparedStatement stmt = conn.prepareStatement(sql)) {
            
            stmt.setInt(1, employeeId);
            stmt.setInt(2, months);
            
            try (ResultSet rs = stmt.executeQuery()) {
                while (rs.next()) {
                    labels.add(rs.getString("month"));
                    technical.add(rs.getDouble("technical_avg"));
                    communication.add(rs.getDouble("communication_avg"));
                }
            }
        } catch (SQLException e) {
            LOGGER.log(Level.SEVERE, "Error getting performance trend data for employee " + employeeId, e);
        }
        
        trendData.put("labels", labels);
        trendData.put("technical", technical);
        trendData.put("communication", communication);
        return trendData;
    }

    public List<Map<String, Object>> getRecentFeedback(int employeeId, int months) {
        List<Map<String, Object>> feedback = new ArrayList<>();
        String sql = "SELECT r.*, u.name as reviewer_name " +
                    "FROM reviews r " +
                    "JOIN users u ON r.reviewer_id = u.id " +
                    "WHERE r.reviewee_id = ? " +
                    "AND r.created_at >= DATEADD('MONTH', -?, CURRENT_TIMESTAMP) " +
                    "AND r.status = 'Completed' " +
                    "ORDER BY r.created_at DESC";
        
        try (Connection conn = DBConnection.getConnection();
             PreparedStatement stmt = conn.prepareStatement(sql)) {
            
            stmt.setInt(1, employeeId);
            stmt.setInt(2, months);
            
            try (ResultSet rs = stmt.executeQuery()) {
                while (rs.next()) {
                    Map<String, Object> review = new HashMap<>();
                    review.put("reviewerName", rs.getString("reviewer_name"));
                    review.put("date", rs.getTimestamp("created_at"));
                    review.put("type", rs.getString("review_type"));
                    review.put("strengths", rs.getString("strengths"));
                    review.put("improvements", rs.getString("improvements"));
                    review.put("comments", rs.getString("comments"));
                    feedback.add(review);
                }
            }
        } catch (SQLException e) {
            LOGGER.log(Level.SEVERE, "Error getting recent feedback for employee " + employeeId, e);
        }
        return feedback;
    }

    public List<Review> findOverdueReviews() {
        List<Review> overdueReviews = new ArrayList<>();
        String sql = "SELECT r.*, u.name as reviewee_name " +
                    "FROM reviews r " +
                    "JOIN users u ON r.reviewee_id = u.id " +
                    "WHERE r.status = 'Pending' " +
                    "AND r.deadline < CURRENT_DATE";
        
        try (Connection conn = DBConnection.getConnection();
             PreparedStatement stmt = conn.prepareStatement(sql)) {
            
            try (ResultSet rs = stmt.executeQuery()) {
                while (rs.next()) {
                    Review review = mapResultSetToReview(rs);
                    review.setRevieweeName(rs.getString("reviewee_name"));
                    
                    // Get reviewer IDs for this review
                    String reviewerSql = "SELECT reviewer_id FROM review_assignments WHERE review_id = ?";
                    try (PreparedStatement reviewerStmt = conn.prepareStatement(reviewerSql)) {
                        reviewerStmt.setInt(1, review.getId());
                        List<Integer> reviewerIds = new ArrayList<>();
                        try (ResultSet reviewerRs = reviewerStmt.executeQuery()) {
                            while (reviewerRs.next()) {
                                reviewerIds.add(reviewerRs.getInt("reviewer_id"));
                            }
                        }
                        review.setReviewerIds(reviewerIds);
                    }
                    
                    overdueReviews.add(review);
                }
            }
        } catch (SQLException e) {
            LOGGER.log(Level.SEVERE, "Error finding overdue reviews", e);
        }
        return overdueReviews;
    }

    public boolean revokeReview(int reviewId) {
        String sql = "UPDATE reviews SET status = 'Revoked', revoke_date = CURRENT_TIMESTAMP " +
                    "WHERE id = ? AND status = 'Pending'";
        
        try (Connection conn = DBConnection.getConnection();
             PreparedStatement stmt = conn.prepareStatement(sql)) {
            
            stmt.setInt(1, reviewId);
            return stmt.executeUpdate() > 0;
        } catch (SQLException e) {
            LOGGER.log(Level.SEVERE, "Error revoking review: " + reviewId, e);
            return false;
        }
    }

    public void createReview(Review review) throws SQLException {
        String sql = "INSERT INTO reviews (reviewee_id, type, deadline, comments, status) VALUES (?, ?, ?, ?, ?)";
        
        try (Connection conn = DatabaseUtil.getConnection();
             PreparedStatement stmt = conn.prepareStatement(sql, Statement.RETURN_GENERATED_KEYS)) {
            
            stmt.setInt(1, review.getReviewee().getId());
            stmt.setString(2, review.getType().name());
            stmt.setDate(3, review.getDeadline());
            stmt.setString(4, review.getComments());
            stmt.setString(5, review.getStatus().name());
            
            stmt.executeUpdate();
            
            try (ResultSet generatedKeys = stmt.getGeneratedKeys()) {
                if (generatedKeys.next()) {
                    review.setId(generatedKeys.getInt(1));
                }
            }
        }
    }

    public List<Review> getReviewsByReviewee(int revieweeId) throws SQLException {
        String sql = "SELECT * FROM reviews WHERE reviewee_id = ?";
        List<Review> reviews = new ArrayList<>();
        
        try (Connection conn = DatabaseUtil.getConnection();
             PreparedStatement stmt = conn.prepareStatement(sql)) {
            
            stmt.setInt(1, revieweeId);
            
            try (ResultSet rs = stmt.executeQuery()) {
                while (rs.next()) {
                    Review review = mapResultSetToReview(rs);
                    reviews.add(review);
                }
            }
        }
        
        return reviews;
    }

    public Review getReviewById(int id) throws SQLException {
        String sql = "SELECT * FROM reviews WHERE id = ?";
        
        try (Connection conn = DatabaseUtil.getConnection();
             PreparedStatement stmt = conn.prepareStatement(sql)) {
            
            stmt.setInt(1, id);
            
            try (ResultSet rs = stmt.executeQuery()) {
                if (rs.next()) {
                    return mapResultSetToReview(rs);
                }
            }
        }
        return null;
    }

    public void updateReview(Review review) throws SQLException {
        String sql = "UPDATE reviews SET type = ?, deadline = ?, comments = ?, status = ? WHERE id = ?";
        
        try (Connection conn = DatabaseUtil.getConnection();
             PreparedStatement stmt = conn.prepareStatement(sql)) {
            
            stmt.setString(1, review.getType().name());
            stmt.setDate(2, review.getDeadline());
            stmt.setString(3, review.getComments());
            stmt.setString(4, review.getStatus().name());
            stmt.setInt(5, review.getId());
            
            stmt.executeUpdate();
        }
    }

    public List<Review> getOverdueReviews() throws SQLException {
        String sql = "SELECT * FROM reviews WHERE deadline < CURRENT_DATE AND status = ?";
        List<Review> reviews = new ArrayList<>();
        
        try (Connection conn = DatabaseUtil.getConnection();
             PreparedStatement stmt = conn.prepareStatement(sql)) {
            
            stmt.setString(1, Review.ReviewStatus.PENDING.name());
            
            try (ResultSet rs = stmt.executeQuery()) {
                while (rs.next()) {
                    Review review = mapResultSetToReview(rs);
                    reviews.add(review);
                }
            }
        }
        
        return reviews;
    }

    private Review mapResultSetToReview(ResultSet rs) throws SQLException {
        Review review = new Review();
        review.setId(rs.getInt("id"));
        review.setReviewee(userDAO.getUserById(rs.getInt("reviewee_id")));
        review.setType(Review.ReviewType.valueOf(rs.getString("type")));
        review.setDeadline(rs.getDate("deadline"));
        review.setComments(rs.getString("comments"));
        review.setStatus(Review.ReviewStatus.valueOf(rs.getString("status")));
        return review;
    }
} 