package com.peerreview.controller;

import java.io.IOException;
import java.util.List;

import javax.servlet.ServletException;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.HttpSession;

import com.peerreview.dao.ThoughtDAO;
import com.peerreview.dao.UserDAO;
import com.peerreview.model.User;

public class DataEntryDashboardServlet extends HttpServlet {
    private UserDAO userDAO;
    private ThoughtDAO thoughtDAO;

    @Override
    public void init() throws ServletException {
        userDAO = new UserDAO();
        thoughtDAO = new ThoughtDAO();
    }

    @Override
    protected void doGet(HttpServletRequest request, HttpServletResponse response) 
            throws ServletException, IOException {
        
        HttpSession session = request.getSession(false);
        User dataEntryUser = (User) session.getAttribute("user");

        // Get user statistics
        int totalUsers = userDAO.countTotalUsers();
        int activeUsers = userDAO.countActiveUsers();
        int newUsers = userDAO.countNewUsers(30); // users created in last 30 days
        int pendingActions = userDAO.countPendingActions();

        // Get list of all users for the table
        List<User> users = userDAO.findAllUsers();

        // Get thought of the day
        String thoughtOfTheDay = thoughtDAO.getThoughtOfTheDay();

        // Set attributes for JSP
        request.setAttribute("totalUsers", totalUsers);
        request.setAttribute("activeUsers", activeUsers);
        request.setAttribute("newUsers", newUsers);
        request.setAttribute("pendingActions", pendingActions);
        request.setAttribute("users", users);
        request.setAttribute("thoughtOfTheDay", thoughtOfTheDay);

        // Forward to dashboard JSP
        request.getRequestDispatcher("/WEB-INF/dataentry/dashboard.jsp").forward(request, response);
    }
} 