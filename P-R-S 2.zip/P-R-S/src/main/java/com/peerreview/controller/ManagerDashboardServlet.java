package com.peerreview.controller;

import java.io.IOException;
import java.util.List;
import java.util.Map;

import javax.servlet.ServletException;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.HttpSession;

import com.google.gson.Gson;
import com.peerreview.dao.ReviewDAO;
import com.peerreview.dao.ThoughtDAO;
import com.peerreview.model.Review;
import com.peerreview.model.User;

public class ManagerDashboardServlet extends HttpServlet {
    private ReviewDAO reviewDAO;
    private ThoughtDAO thoughtDAO;
    private Gson gson;

    @Override
    public void init() throws ServletException {
        reviewDAO = new ReviewDAO();
        thoughtDAO = new ThoughtDAO();
        gson = new Gson();
    }

    @Override
    protected void doGet(HttpServletRequest request, HttpServletResponse response) 
            throws ServletException, IOException {
        
        HttpSession session = request.getSession(false);
        User manager = (User) session.getAttribute("user");

        // Get review statistics
        int totalReviews = reviewDAO.countTotalReviewsByManager(manager.getId());
        int pendingReviews = reviewDAO.countPendingReviewsByManager(manager.getId());
        int completedReviews = reviewDAO.countCompletedReviewsByManager(manager.getId());

        // Get recent reviews (top 5)
        List<Review> recentReviews = reviewDAO.findRecentReviewsByManager(manager.getId(), 5);

        // Get calendar events
        List<Map<String, Object>> calendarEvents = reviewDAO.getCalendarEventsByManager(manager.getId());

        // Get thought of the day
        String thoughtOfTheDay = thoughtDAO.getThoughtOfTheDay();

        // Set attributes for JSP
        request.setAttribute("totalReviews", totalReviews);
        request.setAttribute("pendingReviews", pendingReviews);
        request.setAttribute("completedReviews", completedReviews);
        request.setAttribute("recentReviews", recentReviews);
        request.setAttribute("calendarEvents", gson.toJson(calendarEvents));
        request.setAttribute("thoughtOfTheDay", thoughtOfTheDay);

        // Forward to dashboard JSP
        request.getRequestDispatcher("/WEB-INF/manager/dashboard.jsp").forward(request, response);
    }
} 