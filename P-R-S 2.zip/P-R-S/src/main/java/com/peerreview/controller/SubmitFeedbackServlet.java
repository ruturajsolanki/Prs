package com.peerreview.controller;

import java.io.IOException;

import javax.servlet.ServletException;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.HttpSession;

import com.peerreview.dao.ReviewDAO;
import com.peerreview.dao.UserDAO;
import com.peerreview.model.Review;
import com.peerreview.model.User;

public class SubmitFeedbackServlet extends HttpServlet {
    private ReviewDAO reviewDAO;
    private UserDAO userDAO;

    @Override
    public void init() throws ServletException {
        reviewDAO = new ReviewDAO();
        userDAO = new UserDAO();
    }

    @Override
    protected void doGet(HttpServletRequest request, HttpServletResponse response) 
            throws ServletException, IOException {
        
        HttpSession session = request.getSession(false);
        User reviewer = (User) session.getAttribute("user");
        
        // Get review ID from query parameter
        String reviewId = request.getParameter("id");
        if (reviewId == null || reviewId.trim().isEmpty()) {
            response.sendRedirect("dashboard");
            return;
        }

        // Get review details
        Review review = reviewDAO.findById(Integer.parseInt(reviewId));
        if (review == null || review.getType() != Review.ReviewType.PERFORMANCE) {
            response.sendRedirect("dashboard");
            return;
        }

        // Verify reviewer is assigned to this review
        if (!reviewDAO.isReviewerAssigned(review.getId(), reviewer.getId())) {
            response.sendRedirect("dashboard");
            return;
        }

        // Get reviewee details
        User reviewee = userDAO.findById(review.getRevieweeId());
        
        // Calculate days remaining
        long daysRemaining = reviewDAO.calculateDaysRemaining(review.getId());

        request.setAttribute("review", review);
        request.setAttribute("reviewee", reviewee);
        request.setAttribute("daysRemaining", daysRemaining);
        request.getRequestDispatcher("/WEB-INF/reviewer/feedback-form.jsp").forward(request, response);
    }

    @Override
    protected void doPost(HttpServletRequest request, HttpServletResponse response) 
            throws ServletException, IOException {
        try {
            int reviewId = Integer.parseInt(request.getParameter("reviewId"));
            String feedback = request.getParameter("feedback");
            
            Review review = reviewDAO.getReviewById(reviewId);
            if (review == null) {
                response.sendError(HttpServletResponse.SC_NOT_FOUND, "Review not found");
                return;
            }
            
            if (review.getType() != Review.ReviewType.PERFORMANCE) {
                response.sendError(HttpServletResponse.SC_BAD_REQUEST, "Invalid review type");
                return;
            }
            
            review.setComments(feedback);
            review.setStatus(Review.ReviewStatus.COMPLETED);
            
            reviewDAO.updateReview(review);
            
            response.sendRedirect(request.getContextPath() + "/reviewer/reviews");
            
        } catch (Exception e) {
            throw new ServletException("Error submitting feedback", e);
        }
    }
} 