package com.peerreview.controller;

import java.io.IOException;

import javax.servlet.ServletException;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.HttpSession;

import com.peerreview.dao.UserDAO;
import com.peerreview.model.User;

public class ProfileServlet extends HttpServlet {
    private UserDAO userDAO;

    @Override
    public void init() throws ServletException {
        userDAO = new UserDAO();
    }

    @Override
    protected void doGet(HttpServletRequest request, HttpServletResponse response) 
            throws ServletException, IOException {
        HttpSession session = request.getSession(false);
        User user = (User) session.getAttribute("user");

        String userType = request.getRequestURI().split("/")[2]; // manager, reviewer, or dataentry
        String jspPath = String.format("/WEB-INF/%s/profile.jsp", userType);
        
        request.getRequestDispatcher(jspPath).forward(request, response);
    }

    @Override
    protected void doPost(HttpServletRequest request, HttpServletResponse response) 
            throws ServletException, IOException {
        HttpSession session = request.getSession(false);
        User user = (User) session.getAttribute("user");

        String currentPassword = request.getParameter("currentPassword");
        String newPassword = request.getParameter("newPassword");
        String confirmPassword = request.getParameter("confirmPassword");

        if (currentPassword != null && newPassword != null && confirmPassword != null) {
            // Password change request
            if (!newPassword.equals(confirmPassword)) {
                request.setAttribute("error", "New passwords do not match");
            } else if (!currentPassword.equals(user.getPassword())) {
                request.setAttribute("error", "Current password is incorrect");
            } else {
                // Update with plain text password
                if (userDAO.updatePassword(user.getId(), newPassword)) {
                    request.setAttribute("success", "Password updated successfully");
                    user.setPassword(newPassword);
                    session.setAttribute("user", user);
                } else {
                    request.setAttribute("error", "Failed to update password");
                }
            }
        }

        doGet(request, response);
    }
} 