package com.peerreview.controller;

import java.io.IOException;
import java.sql.Date;
import java.util.List;
import java.util.logging.Logger;
import java.util.stream.Collectors;

import javax.servlet.ServletException;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.HttpSession;

import com.peerreview.dao.ReviewDAO;
import com.peerreview.dao.UserDAO;
import com.peerreview.model.Review;
import com.peerreview.model.User;

public class AssignReviewServlet extends HttpServlet {
    private static final Logger LOGGER = Logger.getLogger(AssignReviewServlet.class.getName());
    private ReviewDAO reviewDAO;
    private UserDAO userDAO;

    @Override
    public void init() throws ServletException {
        reviewDAO = new ReviewDAO();
        userDAO = new UserDAO();
    }

    @Override
    protected void doGet(HttpServletRequest request, HttpServletResponse response) 
            throws ServletException, IOException {
        
        HttpSession session = request.getSession(false);
        User manager = (User) session.getAttribute("user");
        
        try {
            // Get all team members (excluding the manager and data entry users)
            List<User> allUsers = userDAO.getAllUsers();
            LOGGER.info("Found " + allUsers.size() + " total users");
            
            List<User> teamMembers = allUsers.stream()
                    .filter(user -> user.getId() != manager.getId() && 
                                  user.getRole() != User.Role.DataEntry &&
                                  user.getRole() != User.Role.Manager &&
                                  user.getStatus() == User.Status.Active)
                    .collect(Collectors.toList());

            LOGGER.info("Filtered to " + teamMembers.size() + " team members for review assignment");

            // Get all potential reviewers (excluding the manager and data entry)
            List<User> availableReviewers = allUsers.stream()
                    .filter(user -> user.getId() != manager.getId() && 
                                  user.getRole() != User.Role.DataEntry &&
                                  user.getRole() != User.Role.Manager &&
                                  user.getStatus() == User.Status.Active)
                    .collect(Collectors.toList());

            LOGGER.info("Found " + availableReviewers.size() + " available reviewers");

            request.setAttribute("teamMembers", teamMembers);
            request.setAttribute("availableReviewers", availableReviewers);
            request.getRequestDispatcher("/WEB-INF/manager/assign-review.jsp").forward(request, response);
        } catch (Exception e) {
            LOGGER.severe("Error loading assign review page: " + e.getMessage());
            response.sendError(HttpServletResponse.SC_INTERNAL_SERVER_ERROR, "Error loading team members");
        }
    }

    @Override
    protected void doPost(HttpServletRequest request, HttpServletResponse response) 
            throws ServletException, IOException {
        try {
            int revieweeId = Integer.parseInt(request.getParameter("reviewee"));
            String reviewType = request.getParameter("reviewType");
            Date deadline = Date.valueOf(request.getParameter("deadline"));
            
            User reviewee = userDAO.getUserById(revieweeId);
            if (reviewee == null) {
                response.sendError(HttpServletResponse.SC_NOT_FOUND, "Reviewee not found");
                return;
            }
            
            Review review = new Review(reviewee, Review.ReviewType.valueOf(reviewType), deadline);
            reviewDAO.createReview(review);
            
            response.sendRedirect(request.getContextPath() + "/manager/dashboard?success=Review assigned successfully");
            
        } catch (Exception e) {
            throw new ServletException("Error assigning review", e);
        }
    }
} 