package com.peerreview.task;

import java.util.List;
import java.util.concurrent.Executors;
import java.util.concurrent.ScheduledExecutorService;
import java.util.concurrent.TimeUnit;
import java.util.logging.Level;
import java.util.logging.Logger;

import javax.servlet.ServletContextEvent;
import javax.servlet.ServletContextListener;
import javax.servlet.annotation.WebListener;

import com.peerreview.dao.ReviewDAO;
import com.peerreview.model.Review;
import com.peerreview.util.NotificationUtil;

@WebListener
public class ReviewRevokeTask implements ServletContextListener {
    private static final Logger LOGGER = Logger.getLogger(ReviewRevokeTask.class.getName());
    private ScheduledExecutorService scheduler;
    private ReviewDAO reviewDAO;

    @Override
    public void contextInitialized(ServletContextEvent event) {
        scheduler = Executors.newSingleThreadScheduledExecutor();
        reviewDAO = new ReviewDAO();
        
        // Run the task daily at midnight
        scheduler.scheduleAtFixedRate(this::checkAndRevokeReviews, 0, 1, TimeUnit.DAYS);
        
        LOGGER.info("Review revocation task scheduled successfully");
    }

    @Override
    public void contextDestroyed(ServletContextEvent event) {
        scheduler.shutdownNow();
        LOGGER.info("Review revocation task stopped");
    }

    private void checkAndRevokeReviews() {
        try {
            List<Review> overdueReviews = reviewDAO.getOverdueReviews();
            
            for (Review review : overdueReviews) {
                // Send notification to reviewee
                String message = String.format("Your review has been automatically revoked due to passing the deadline.");
                NotificationUtil.sendNotification(0, review.getReviewee().getId(), message);
                
                // Update review status
                review.setStatus(Review.ReviewStatus.COMPLETED);
                reviewDAO.updateReview(review);
            }
            
        } catch (Exception e) {
            LOGGER.log(Level.SEVERE, "Error in review revocation task", e);
        }
    }
} 