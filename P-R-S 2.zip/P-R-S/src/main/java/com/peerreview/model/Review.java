package com.peerreview.model;

import java.sql.Date;
import java.sql.Timestamp;
import java.util.List;

public class Review {
    private int id;
    private User reviewee;
    private ReviewType type;
    private Date deadline;
    private String comments;
    private ReviewStatus status;
    private Timestamp createdAt;
    private String revieweeName;
    private int daysRemaining;
    private List<Integer> reviewerIds;

    public enum ReviewType {
        QUARTERLY, ANNUAL, PERFORMANCE
    }

    public enum ReviewStatus {
        PENDING, IN_PROGRESS, COMPLETED
    }

    // Default constructor
    public Review() {
        this.status = ReviewStatus.PENDING;
    }

    // Constructor with essential fields
    public Review(User reviewee, ReviewType type, Date deadline) {
        this.reviewee = reviewee;
        this.type = type;
        this.deadline = deadline;
        this.status = ReviewStatus.PENDING;
    }

    // Getters and Setters
    public int getId() {
        return id;
    }

    public void setId(int id) {
        this.id = id;
    }

    public User getReviewee() {
        return reviewee;
    }

    public void setReviewee(User reviewee) {
        this.reviewee = reviewee;
    }

    public int getRevieweeId() {
        return reviewee != null ? reviewee.getId() : 0;
    }

    public ReviewType getType() {
        return type;
    }

    public void setType(ReviewType type) {
        this.type = type;
    }

    public Date getDeadline() {
        return deadline;
    }

    public void setDeadline(Date deadline) {
        this.deadline = deadline;
    }

    public String getComments() {
        return comments;
    }

    public void setComments(String comments) {
        this.comments = comments;
    }

    public ReviewStatus getStatus() {
        return status;
    }

    public void setStatus(ReviewStatus status) {
        this.status = status;
    }

    public Timestamp getCreatedAt() {
        return createdAt;
    }

    public void setCreatedAt(Timestamp createdAt) {
        this.createdAt = createdAt;
    }

    public String getRevieweeName() {
        return revieweeName;
    }

    public void setRevieweeName(String revieweeName) {
        this.revieweeName = revieweeName;
    }

    public int getDaysRemaining() {
        return daysRemaining;
    }

    public void setDaysRemaining(int daysRemaining) {
        this.daysRemaining = daysRemaining;
    }

    public List<Integer> getReviewerIds() {
        return reviewerIds;
    }

    public void setReviewerIds(List<Integer> reviewerIds) {
        this.reviewerIds = reviewerIds;
    }
} 