package com.peerreview.filter;

import java.io.IOException;
import java.util.logging.Logger;

import javax.servlet.Filter;
import javax.servlet.FilterChain;
import javax.servlet.FilterConfig;
import javax.servlet.ServletException;
import javax.servlet.ServletRequest;
import javax.servlet.ServletResponse;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.HttpSession;

import com.peerreview.model.User;
import com.peerreview.model.User.Role;

public class RoleBasedAccessFilter implements Filter {
    private static final Logger LOGGER = Logger.getLogger(RoleBasedAccessFilter.class.getName());

    @Override
    public void init(FilterConfig filterConfig) throws ServletException {
        LOGGER.info("RoleBasedAccessFilter initialized");
    }

    @Override
    public void doFilter(ServletRequest request, ServletResponse response, FilterChain chain)
            throws IOException, ServletException {
        HttpServletRequest httpRequest = (HttpServletRequest) request;
        HttpServletResponse httpResponse = (HttpServletResponse) response;
        HttpSession session = httpRequest.getSession(false);

        if (session == null || session.getAttribute("user") == null) {
            LOGGER.warning("Unauthorized access attempt: No session or user");
            httpResponse.sendRedirect(httpRequest.getContextPath() + "/login");
            return;
        }

        User user = (User) session.getAttribute("user");
        String requestURI = httpRequest.getRequestURI();
        String contextPath = httpRequest.getContextPath();
        String path = requestURI.substring(contextPath.length());

        boolean isAuthorized = false;
        if (path.startsWith("/manager/")) {
            isAuthorized = user.getRole() == Role.Manager;
        } else if (path.startsWith("/dataentry/")) {
            isAuthorized = user.getRole() == Role.DataEntry;
        } else if (path.startsWith("/reviewer/")) {
            isAuthorized = user.getRole() == Role.TeamLead || user.getRole() == Role.SSE || 
                          user.getRole() == Role.JSE || user.getRole() == Role.Intern;
        }

        if (isAuthorized) {
            LOGGER.info("Access granted to " + user.getEmail() + " for " + path);
            chain.doFilter(request, response);
        } else {
            LOGGER.warning("Unauthorized access attempt by " + user.getEmail() + " to " + path);
            httpResponse.sendError(HttpServletResponse.SC_FORBIDDEN, "Access denied");
        }
    }

    @Override
    public void destroy() {
        LOGGER.info("RoleBasedAccessFilter destroyed");
    }
} 