document.addEventListener('DOMContentLoaded', function() {
    // Initialize employee data
    const employees = [
        { id: 1, name: 'Employee 1' },
        { id: 2, name: 'Employee 2' },
        { id: 3, name: 'Employee 3' },
        { id: 4, name: 'Employee 4' }
    ];

    const employeeList = document.getElementById('employeeList');
    const assignedList = document.getElementById('assignedList');
    const moveRight = document.getElementById('moveRight');
    const moveLeft = document.getElementById('moveLeft');
    const assignButton = document.getElementById('assignButton');

    // Populate employee list
    function populateEmployeeList() {
        employeeList.innerHTML = '';
        employees.forEach(employee => {
            const item = document.createElement('a');
            item.href = '#';
            item.className = 'list-group-item list-group-item-action d-flex align-items-center';
            item.innerHTML = `<i class="bi bi-person-circle me-2"></i>${employee.name}`;
            item.dataset.id = employee.id;
            employeeList.appendChild(item);
        });
    }

    // Event listeners for selection
    employeeList.addEventListener('click', function(e) {
        if (e.target.classList.contains('list-group-item')) {
            e.target.classList.toggle('active');
        }
    });

    assignedList.addEventListener('click', function(e) {
        if (e.target.classList.contains('list-group-item')) {
            e.target.classList.toggle('active');
        }
    });

    // Move selected employees right
    moveRight.addEventListener('click', function() {
        const selected = employeeList.querySelectorAll('.active');
        const currentAssigned = assignedList.children.length;

        if (currentAssigned + selected.length > 3) {
            alert('Maximum 3 reviewers can be assigned');
            return;
        }

        selected.forEach(item => {
            const clone = item.cloneNode(true);
            clone.classList.remove('active');
            assignedList.appendChild(clone);
            item.remove();
        });
    });

    // Move selected employees left
    moveLeft.addEventListener('click', function() {
        const selected = assignedList.querySelectorAll('.active');
        selected.forEach(item => {
            const clone = item.cloneNode(true);
            clone.classList.remove('active');
            employeeList.appendChild(clone);
            item.remove();
        });
    });

    // Assign button functionality
    assignButton.addEventListener('click', function() {
        const formType = document.getElementById('formType').value;
        const reviewDate = document.getElementById('reviewDate').value;
        const assignedDate = document.getElementById('assignedDate').value;
        
        if (!formType || !reviewDate || !assignedDate) {
            alert('Please fill in all required fields');
            return;
        }

        const assignedEmployees = Array.from(assignedList.children).map(item => ({
            id: item.dataset.id,
            name: item.textContent
        }));

        if (assignedEmployees.length < 1) {
            alert('Please assign at least one reviewer');
            return;
        }

        // Here you would typically send this data to your backend
        const assignmentData = {
            formType,
            reviewDate,
            assignedDate,
            assignedEmployees
        };

        console.log('Assignment data:', assignmentData);
        alert('Review assignment successful!');
    });

    // Initial population
    populateEmployeeList();

    // Date validation
    document.getElementById('assignedDate').addEventListener('change', function(e) {
        const assignedDate = new Date(e.target.value);
        const dueDate = new Date(assignedDate);
        dueDate.setDate(dueDate.getDate() + 7);
        
        document.getElementById('reviewDate').min = dueDate.toISOString().split('T')[0];
    });
});
