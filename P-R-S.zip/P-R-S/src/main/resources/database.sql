-- Create the database
CREATE DATABASE IF NOT EXISTS peer_review_db;
USE peer_review_db;

-- Users table
CREATE TABLE IF NOT EXISTS users (
    id INT AUTO_INCREMENT PRIMARY KEY,
    name VARCHAR(100) NOT NULL,
    email VARCHAR(100) NOT NULL UNIQUE,
    password VARCHAR(255) NOT NULL,
    role ENUM('Manager', 'TeamLead', 'SSE', 'JSE', 'Intern', 'DataEntry') NOT NULL,
    status ENUM('Active', 'Inactive') DEFAULT 'Active',
    created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
    updated_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP
);

-- Reviews table
CREATE TABLE IF NOT EXISTS reviews (
    id INT AUTO_INCREMENT PRIMARY KEY,
    reviewee_id INT NOT NULL,
    manager_id INT NOT NULL,
    type ENUM('KRA', 'Feedback') NOT NULL,
    status ENUM('Pending', 'InProgress', 'Completed', 'Revoked') DEFAULT 'Pending',
    deadline DATE NOT NULL,
    assigned_date TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
    revoke_date TIMESTAMP NULL,
    finalized_by_manager BOOLEAN DEFAULT FALSE,
    FOREIGN KEY (reviewee_id) REFERENCES users(id),
    FOREIGN KEY (manager_id) REFERENCES users(id)
);

-- Review Assignments table
CREATE TABLE IF NOT EXISTS review_assignments (
    id INT AUTO_INCREMENT PRIMARY KEY,
    review_id INT NOT NULL,
    reviewer_id INT NOT NULL,
    status ENUM('NotStarted', 'InProgress', 'Completed') DEFAULT 'NotStarted',
    FOREIGN KEY (review_id) REFERENCES reviews(id),
    FOREIGN KEY (reviewer_id) REFERENCES users(id)
);

-- KRA Form table
CREATE TABLE IF NOT EXISTS kra_form (
    id INT AUTO_INCREMENT PRIMARY KEY,
    review_id INT NOT NULL,
    category VARCHAR(100) NOT NULL,
    question TEXT NOT NULL,
    response INT CHECK (response >= 1 AND response <= 5),
    comment TEXT,
    FOREIGN KEY (review_id) REFERENCES reviews(id)
);

-- Feedback Form table
CREATE TABLE IF NOT EXISTS feedback_form (
    id INT AUTO_INCREMENT PRIMARY KEY,
    review_id INT NOT NULL,
    question_1_response TEXT,
    question_2_response TEXT,
    comment TEXT,
    FOREIGN KEY (review_id) REFERENCES reviews(id)
);

-- Notifications table
CREATE TABLE IF NOT EXISTS notifications (
    id INT AUTO_INCREMENT PRIMARY KEY,
    sender_id INT NOT NULL,
    receiver_id INT NOT NULL,
    message TEXT NOT NULL,
    is_read BOOLEAN DEFAULT FALSE,
    created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
    FOREIGN KEY (sender_id) REFERENCES users(id),
    FOREIGN KEY (receiver_id) REFERENCES users(id)
);

-- Thoughts table
CREATE TABLE IF NOT EXISTS thoughts (
    id INT AUTO_INCREMENT PRIMARY KEY,
    message TEXT NOT NULL,
    date DATE DEFAULT (CURRENT_DATE),
    created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP
);

-- Insert default admin user with plain text password (admin123)
INSERT INTO users (name, email, password, role) 
VALUES ('Admin', 'admin@example.com', 'admin123', 'Manager')
ON DUPLICATE KEY UPDATE id=id;

-- Insert data entry user with plain text password (dataentry123)
INSERT INTO users (name, email, password, role) 
VALUES ('Data Entry User', 'dataentry@example.com', 'dataentry123', 'DataEntry')
ON DUPLICATE KEY UPDATE id=id;

-- Insert test user with plain text password (test123)
INSERT INTO users (name, email, password, role) 
VALUES ('Test User', 'test@example.com', 'test123', 'Manager')
ON DUPLICATE KEY UPDATE id=id;

-- Insert test users
INSERT INTO users (name, email, password, role) VALUES
('John Developer', 'john@example.com', 'test123', 'SSE'),
('Jane Team Lead', 'jane@example.com', 'test123', 'TeamLead'),
('Bob Junior', 'bob@example.com', 'test123', 'JSE'),
('Alice Intern', 'alice@example.com', 'test123', 'Intern')
ON DUPLICATE KEY UPDATE id=id; 