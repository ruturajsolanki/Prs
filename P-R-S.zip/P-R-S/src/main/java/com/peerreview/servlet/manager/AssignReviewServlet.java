package com.peerreview.servlet.manager;

import com.peerreview.dao.UserDAO;
import com.peerreview.dao.ReviewDAO;
import com.peerreview.model.User;
import com.peerreview.model.Review;
import com.peerreview.model.Role;

import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import java.io.IOException;
import java.util.List;
import java.time.LocalDate;
import java.sql.Date;
import java.util.stream.Collectors;

@WebServlet("/manager/assign-review")
public class AssignReviewServlet extends HttpServlet {
    private UserDAO userDAO;
    private ReviewDAO reviewDAO;

    @Override
    public void init() throws ServletException {
        userDAO = new UserDAO();
        reviewDAO = new ReviewDAO();
    }

    @Override
    protected void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
        List<User> allUsers = userDAO.getAllUsers();
        
        // Filter out managers and data entry users, keep only active employees
        List<User> employees = allUsers.stream()
            .filter(user -> user.getStatus().equals("ACTIVE"))
            .filter(user -> !user.getRole().equals("Manager") && !user.getRole().equals("DataEntry"))
            .collect(Collectors.toList());
        
        request.setAttribute("employees", employees);
        request.setAttribute("today", LocalDate.now().toString());
        request.getRequestDispatcher("/WEB-INF/manager/assign-review.jsp").forward(request, response);
    }

    @Override
    protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
        try {
            int revieweeId = Integer.parseInt(request.getParameter("reviewee"));
            String reviewTypeStr = request.getParameter("reviewType");
            Date deadline = Date.valueOf(request.getParameter("deadline"));
            String comments = request.getParameter("comments");
            
            User reviewee = userDAO.getUserById(revieweeId);
            if (reviewee == null) {
                request.setAttribute("message", "Selected employee not found.");
                request.setAttribute("messageType", "error");
                doGet(request, response);
                return;
            }
            
            Review review = new Review();
            review.setReviewee(reviewee);
            review.setType(Review.ReviewType.valueOf(reviewTypeStr));
            review.setDeadline(deadline);
            review.setComments(comments);
            review.setStatus(Review.ReviewStatus.PENDING);
            
            reviewDAO.createReview(review);
            
            request.setAttribute("message", "Review assigned successfully!");
            request.setAttribute("messageType", "success");
            
        } catch (Exception e) {
            request.setAttribute("message", "Error assigning review: " + e.getMessage());
            request.setAttribute("messageType", "error");
        }
        
        doGet(request, response);
    }
} 