package com.peerreview.task;

import java.util.List;
import java.util.concurrent.Executors;
import java.util.concurrent.ScheduledExecutorService;
import java.util.concurrent.TimeUnit;
import java.util.logging.Level;
import java.util.logging.Logger;

import javax.servlet.ServletContextEvent;
import javax.servlet.ServletContextListener;
import javax.servlet.annotation.WebListener;

import com.peerreview.dao.ReviewDAO;
import com.peerreview.model.Review;
import com.peerreview.util.NotificationUtil;

@WebListener
public class ReviewRevokeTask implements ServletContextListener {
    private static final Logger LOGGER = Logger.getLogger(ReviewRevokeTask.class.getName());
    private ScheduledExecutorService scheduler;
    private ReviewDAO reviewDAO;

    @Override
    public void contextInitialized(ServletContextEvent event) {
        scheduler = Executors.newSingleThreadScheduledExecutor();
        reviewDAO = new ReviewDAO();
        
        // Schedule the task to run every hour
        scheduler.scheduleAtFixedRate(() -> {
            try {
                checkAndRevokeOverdueReviews();
            } catch (Exception e) {
                LOGGER.log(Level.SEVERE, "Error in review revocation task", e);
            }
        }, 0, 1, TimeUnit.HOURS);
        
        LOGGER.info("Review revocation task scheduled successfully");
    }

    @Override
    public void contextDestroyed(ServletContextEvent event) {
        scheduler.shutdownNow();
        LOGGER.info("Review revocation task stopped");
    }

    private void checkAndRevokeOverdueReviews() {
        // Get all overdue reviews
        List<Review> overdueReviews = reviewDAO.findOverdueReviews();
        
        for (Review review : overdueReviews) {
            try {
                // Update review status to Revoked
                if (reviewDAO.revokeReview(review.getId())) {
                    // Send notification to manager
                    String message = String.format("Review for %s has been automatically revoked due to exceeding the deadline.", 
                            review.getRevieweeName());
                    NotificationUtil.sendNotification(0, review.getManagerId(), message);
                    
                    // Send notification to reviewers
                    String reviewerMessage = String.format("Your review assignment for %s has been revoked due to exceeding the deadline.", 
                            review.getRevieweeName());
                    for (int reviewerId : review.getReviewerIds()) {
                        NotificationUtil.sendNotification(0, reviewerId, reviewerMessage);
                    }
                    
                    LOGGER.info("Successfully revoked review ID: " + review.getId());
                }
            } catch (Exception e) {
                LOGGER.log(Level.SEVERE, "Error revoking review ID: " + review.getId(), e);
            }
        }
    }
} 