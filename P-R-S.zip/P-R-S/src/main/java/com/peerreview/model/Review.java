package com.peerreview.model;

import java.sql.Date;

public class Review {
    private int id;
    private User reviewee;
    private ReviewType type;
    private Date deadline;
    private String comments;
    private ReviewStatus status;

    public enum ReviewType {
        QUARTERLY, ANNUAL, PERFORMANCE
    }

    public enum ReviewStatus {
        PENDING, IN_PROGRESS, COMPLETED
    }

    // Default constructor
    public Review() {
    }

    // Constructor with essential fields
    public Review(User reviewee, ReviewType type, Date deadline) {
        this.reviewee = reviewee;
        this.type = type;
        this.deadline = deadline;
        this.status = ReviewStatus.PENDING;
    }

    // Getters and Setters
    public int getId() {
        return id;
    }

    public void setId(int id) {
        this.id = id;
    }

    public User getReviewee() {
        return reviewee;
    }

    public void setReviewee(User reviewee) {
        this.reviewee = reviewee;
    }

    public ReviewType getType() {
        return type;
    }

    public void setType(ReviewType type) {
        this.type = type;
    }

    public Date getDeadline() {
        return deadline;
    }

    public void setDeadline(Date deadline) {
        this.deadline = deadline;
    }

    public String getComments() {
        return comments;
    }

    public void setComments(String comments) {
        this.comments = comments;
    }

    public ReviewStatus getStatus() {
        return status;
    }

    public void setStatus(ReviewStatus status) {
        this.status = status;
    }
} 