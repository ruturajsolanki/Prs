package com.peerreview.model;

import java.sql.Timestamp;

public class User {
    private int id;
    private String name;
    private String email;
    private String password;
    private Role role;
    private Status status;
    private boolean emailNotifications;
    private boolean reviewReminders;
    private Timestamp createdAt;
    private Timestamp updatedAt;

    public enum Role {
        Manager,
        TeamLead,
        SSE,
        JSE,
        Intern,
        DataEntry;

        public static Role fromString(String value) {
            try {
                return Role.valueOf(value);
            } catch (IllegalArgumentException e) {
                return null;
            }
        }
    }

    public enum Status {
        Active,
        Inactive;

        public static Status fromString(String value) {
            try {
                return Status.valueOf(value);
            } catch (IllegalArgumentException e) {
                return Status.Active;
            }
        }
    }

    // Default constructor
    public User() {}

    // Constructor with main fields
    public User(String name, String email, String password, Role role) {
        this.name = name;
        this.email = email;
        this.password = password;
        this.role = role;
        this.status = Status.Active;
    }

    // Getters and Setters
    public int getId() {
        return id;
    }

    public void setId(int id) {
        this.id = id;
    }

    public String getName() {
        return name;
    }

    public void setName(String name) {
        this.name = name;
    }

    public String getEmail() {
        return email;
    }

    public void setEmail(String email) {
        this.email = email;
    }

    public String getPassword() {
        return password;
    }

    public void setPassword(String password) {
        this.password = password;
    }

    public Role getRole() {
        return role;
    }

    public void setRole(Role role) {
        this.role = role;
    }

    public void setRole(String role) {
        this.role = Role.fromString(role);
    }

    public Status getStatus() {
        return status;
    }

    public void setStatus(Status status) {
        this.status = status;
    }

    public void setStatus(String status) {
        this.status = Status.fromString(status);
    }

    public boolean isEmailNotifications() {
        return emailNotifications;
    }

    public void setEmailNotifications(boolean emailNotifications) {
        this.emailNotifications = emailNotifications;
    }

    public boolean isReviewReminders() {
        return reviewReminders;
    }

    public void setReviewReminders(boolean reviewReminders) {
        this.reviewReminders = reviewReminders;
    }

    public Timestamp getCreatedAt() {
        return createdAt;
    }

    public void setCreatedAt(Timestamp createdAt) {
        this.createdAt = createdAt;
    }

    public Timestamp getUpdatedAt() {
        return updatedAt;
    }

    public void setUpdatedAt(Timestamp updatedAt) {
        this.updatedAt = updatedAt;
    }

    @Override
    public String toString() {
        return "User{" +
                "id=" + id +
                ", name='" + name + '\'' +
                ", email='" + email + '\'' +
                ", role=" + role +
                ", status=" + status +
                '}';
    }
} 