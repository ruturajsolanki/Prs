package com.peerreview.util;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.SQLException;
import java.util.logging.Level;
import java.util.logging.Logger;

public class NotificationUtil {
    private static final Logger LOGGER = Logger.getLogger(NotificationUtil.class.getName());

    public static boolean sendNotification(int senderId, int receiverId, String message) {
        String sql = "INSERT INTO notifications (sender_id, receiver_id, message) VALUES (?, ?, ?)";
        
        try (Connection conn = DBConnection.getConnection();
             PreparedStatement stmt = conn.prepareStatement(sql)) {
            
            stmt.setInt(1, senderId);
            stmt.setInt(2, receiverId);
            stmt.setString(3, message);
            
            return stmt.executeUpdate() > 0;
        } catch (SQLException e) {
            LOGGER.log(Level.SEVERE, "Error sending notification", e);
            return false;
        }
    }
} 