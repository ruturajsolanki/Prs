package com.peerreview.controller;

import java.io.IOException;
import java.sql.Date;
import java.util.Arrays;
import java.util.List;
import java.util.logging.Logger;
import java.util.stream.Collectors;

import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.HttpSession;

import com.peerreview.dao.ReviewDAO;
import com.peerreview.dao.UserDAO;
import com.peerreview.model.Review;
import com.peerreview.model.User;
import com.peerreview.util.NotificationUtil;

@WebServlet("/manager/assign-review")
public class AssignReviewServlet extends HttpServlet {
    private static final Logger LOGGER = Logger.getLogger(AssignReviewServlet.class.getName());
    private ReviewDAO reviewDAO;
    private UserDAO userDAO;

    @Override
    public void init() throws ServletException {
        reviewDAO = new ReviewDAO();
        userDAO = new UserDAO();
    }

    @Override
    protected void doGet(HttpServletRequest request, HttpServletResponse response) 
            throws ServletException, IOException {
        
        HttpSession session = request.getSession(false);
        User manager = (User) session.getAttribute("user");
        
        try {
            // Get all team members (excluding the manager and data entry users)
            List<User> allUsers = userDAO.getAllUsers();
            LOGGER.info("Found " + allUsers.size() + " total users");
            
            List<User> teamMembers = allUsers.stream()
                    .filter(user -> user.getId() != manager.getId() && 
                                  user.getRole() != User.Role.DataEntry &&
                                  user.getRole() != User.Role.Manager &&
                                  user.getStatus() == User.Status.Active)
                    .collect(Collectors.toList());

            LOGGER.info("Filtered to " + teamMembers.size() + " team members for review assignment");

            // Get all potential reviewers (excluding the manager and data entry)
            List<User> availableReviewers = allUsers.stream()
                    .filter(user -> user.getId() != manager.getId() && 
                                  user.getRole() != User.Role.DataEntry &&
                                  user.getRole() != User.Role.Manager &&
                                  user.getStatus() == User.Status.Active)
                    .collect(Collectors.toList());

            LOGGER.info("Found " + availableReviewers.size() + " available reviewers");

            request.setAttribute("teamMembers", teamMembers);
            request.setAttribute("availableReviewers", availableReviewers);
            request.getRequestDispatcher("/WEB-INF/manager/assign-review.jsp").forward(request, response);
        } catch (Exception e) {
            LOGGER.severe("Error loading assign review page: " + e.getMessage());
            response.sendError(HttpServletResponse.SC_INTERNAL_SERVER_ERROR, "Error loading team members");
        }
    }

    @Override
    protected void doPost(HttpServletRequest request, HttpServletResponse response) 
            throws ServletException, IOException {
        
        HttpSession session = request.getSession(false);
        User manager = (User) session.getAttribute("user");

        try {
            // Get form parameters
            int revieweeId = Integer.parseInt(request.getParameter("revieweeId"));
            String[] reviewerIdsStr = request.getParameterValues("reviewerIds");
            String reviewType = request.getParameter("reviewType");
            Date deadline = Date.valueOf(request.getParameter("deadline"));

            // Validate reviewers count
            if (reviewerIdsStr == null || reviewerIdsStr.length == 0 || reviewerIdsStr.length > 3) {
                request.setAttribute("error", "Please select between 1 and 3 reviewers.");
                doGet(request, response);
                return;
            }

            // Convert reviewer IDs to integers
            List<Integer> reviewerIds = Arrays.stream(reviewerIdsStr)
                    .map(Integer::parseInt)
                    .collect(Collectors.toList());

            // Validate reviewee is not in reviewers
            if (reviewerIds.contains(revieweeId)) {
                request.setAttribute("error", "A team member cannot review themselves.");
                doGet(request, response);
                return;
            }

            // Create review
            Review review = new Review(revieweeId, manager.getId(), 
                    Review.ReviewType.valueOf(reviewType), deadline);
            
            // Save review and assignments
            if (reviewDAO.createReviewWithAssignments(review, reviewerIds)) {
                // Send notifications to reviewers
                User reviewee = userDAO.findById(revieweeId);
                String message = String.format("You have been assigned to review %s's %s review. Deadline: %s", 
                        reviewee.getName(), reviewType, deadline.toString());
                
                for (Integer reviewerId : reviewerIds) {
                    NotificationUtil.sendNotification(manager.getId(), reviewerId, message);
                }

                request.setAttribute("success", "Review has been successfully assigned.");
            } else {
                request.setAttribute("error", "Failed to assign review. Please try again.");
            }

        } catch (Exception e) {
            request.setAttribute("error", "An error occurred while assigning the review.");
        }

        doGet(request, response);
    }
} 