package com.peerreview.controller;

import java.io.IOException;
import java.util.List;
import java.util.logging.Logger;

import javax.servlet.ServletException;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.HttpSession;

import com.peerreview.dao.UserDAO;
import com.peerreview.model.User;
import com.peerreview.model.User.Role;

public class AllUsersServlet extends HttpServlet {
    private static final Logger LOGGER = Logger.getLogger(AllUsersServlet.class.getName());
    private UserDAO userDAO;

    @Override
    public void init() throws ServletException {
        userDAO = new UserDAO();
        LOGGER.info("AllUsersServlet initialized");
    }

    @Override
    protected void doGet(HttpServletRequest request, HttpServletResponse response) 
            throws ServletException, IOException {
        HttpSession session = request.getSession(false);
        User currentUser = (User) session.getAttribute("user");

        if (currentUser == null || currentUser.getRole() != Role.Manager) {
            LOGGER.warning("Unauthorized access attempt to all-users page");
            response.sendRedirect(request.getContextPath() + "/login");
            return;
        }

        try {
            List<User> users = userDAO.getAllUsers();
            request.setAttribute("users", users);
            LOGGER.info("Retrieved " + users.size() + " users");
            request.getRequestDispatcher("/WEB-INF/manager/all-users.jsp").forward(request, response);
        } catch (Exception e) {
            LOGGER.severe("Error retrieving users: " + e.getMessage());
            response.sendError(HttpServletResponse.SC_INTERNAL_SERVER_ERROR, "Error retrieving users");
        }
    }

    @Override
    protected void doPost(HttpServletRequest request, HttpServletResponse response) 
            throws ServletException, IOException {
        HttpSession session = request.getSession(false);
        User currentUser = (User) session.getAttribute("user");

        if (currentUser == null || currentUser.getRole() != Role.Manager) {
            LOGGER.warning("Unauthorized access attempt to modify users");
            response.sendRedirect(request.getContextPath() + "/login");
            return;
        }

        String action = request.getParameter("action");
        int userId = Integer.parseInt(request.getParameter("userId"));

        try {
            boolean success = false;
            String message = "";

            switch (action) {
                case "edit":
                    User user = userDAO.findById(userId);
                    if (user != null) {
                        // For now, just toggle the status as an example
                        success = userDAO.toggleUserStatus(userId);
                        message = success ? "User status updated successfully" : "Failed to update user status";
                    } else {
                        message = "User not found";
                    }
                    break;
                case "delete":
                    success = userDAO.deleteUser(userId);
                    message = success ? "User deleted successfully" : "Failed to delete user";
                    break;
                case "toggleStatus":
                    success = userDAO.toggleUserStatus(userId);
                    message = success ? "User status toggled successfully" : "Failed to toggle user status";
                    break;
                default:
                    LOGGER.warning("Invalid action requested: " + action);
                    response.sendError(HttpServletResponse.SC_BAD_REQUEST, "Invalid action");
                    return;
            }

            response.setContentType("application/json");
            String jsonResponse = String.format("{\"success\": %b, \"message\": \"%s\"}", success, message);
            response.getWriter().write(jsonResponse);
        } catch (Exception e) {
            LOGGER.severe("Error processing user action: " + e.getMessage());
            response.sendError(HttpServletResponse.SC_INTERNAL_SERVER_ERROR, "Error processing request");
        }
    }
} 