package com.peerreview.controller;

import java.io.IOException;

import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.HttpSession;

import com.peerreview.dao.UserDAO;
import com.peerreview.model.User;
import com.peerreview.util.NotificationUtil;

@WebServlet("/dataentry/add-user")
public class AddUserServlet extends HttpServlet {
    private UserDAO userDAO;

    @Override
    public void init() throws ServletException {
        userDAO = new UserDAO();
    }

    @Override
    protected void doGet(HttpServletRequest request, HttpServletResponse response) 
            throws ServletException, IOException {
        request.getRequestDispatcher("/WEB-INF/dataentry/add-user.jsp").forward(request, response);
    }

    @Override
    protected void doPost(HttpServletRequest request, HttpServletResponse response) 
            throws ServletException, IOException {
        
        HttpSession session = request.getSession(false);
        User dataEntryUser = (User) session.getAttribute("user");

        try {
            // Get form parameters
            String name = request.getParameter("name");
            String email = request.getParameter("email");
            String password = request.getParameter("password");
            String confirmPassword = request.getParameter("confirmPassword");
            String roleStr = request.getParameter("role");

            // Validate input
            if (name == null || email == null || password == null || roleStr == null ||
                name.trim().isEmpty() || email.trim().isEmpty() || password.trim().isEmpty()) {
                request.setAttribute("error", "All fields are required.");
                doGet(request, response);
                return;
            }

            // Validate password match
            if (!password.equals(confirmPassword)) {
                request.setAttribute("error", "Passwords do not match.");
                doGet(request, response);
                return;
            }

            // Check if email already exists
            if (userDAO.findByEmail(email) != null) {
                request.setAttribute("error", "Email already exists.");
                doGet(request, response);
                return;
            }

            // Create new user with plain text password
            User newUser = new User();
            newUser.setName(name);
            newUser.setEmail(email);
            newUser.setPassword(password); // Store password as plain text
            newUser.setRole(User.Role.valueOf(roleStr));
            newUser.setStatus(User.Status.Active);

            if (userDAO.create(newUser)) {
                // Send notification to the new user
                String message = String.format("Welcome to the Peer Review System! Your account has been created by %s.", 
                        dataEntryUser.getName());
                NotificationUtil.sendNotification(dataEntryUser.getId(), newUser.getId(), message);

                request.setAttribute("success", "User created successfully.");
            } else {
                request.setAttribute("error", "Failed to create user. Please try again.");
            }

        } catch (IllegalArgumentException e) {
            request.setAttribute("error", "Invalid role selected.");
        } catch (Exception e) {
            request.setAttribute("error", "An error occurred while creating the user.");
        }

        doGet(request, response);
    }
} 