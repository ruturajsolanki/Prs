package com.peerreview.controller;

import java.io.IOException;
import java.util.List;
import java.util.Map;

import javax.servlet.ServletException;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.HttpSession;

import com.peerreview.dao.NotificationDAO;
import com.peerreview.model.User;

public class NotificationsServlet extends HttpServlet {
    private NotificationDAO notificationDAO;

    @Override
    public void init() throws ServletException {
        notificationDAO = new NotificationDAO();
    }

    @Override
    protected void doGet(HttpServletRequest request, HttpServletResponse response) 
            throws ServletException, IOException {
        HttpSession session = request.getSession(false);
        User user = (User) session.getAttribute("user");

        // Get notifications for the user
        List<Map<String, Object>> notifications = notificationDAO.getNotificationsForUser(user.getId());
        request.setAttribute("notifications", notifications);

        // Get unread count
        int unreadCount = notificationDAO.getUnreadCount(user.getId());
        request.setAttribute("unreadCount", unreadCount);

        String userType = request.getRequestURI().split("/")[2]; // manager, reviewer, or dataentry
        String jspPath = String.format("/WEB-INF/%s/notifications.jsp", userType);
        
        request.getRequestDispatcher(jspPath).forward(request, response);
    }

    @Override
    protected void doPost(HttpServletRequest request, HttpServletResponse response) 
            throws ServletException, IOException {
        String action = request.getParameter("action");
        if ("markAsRead".equals(action)) {
            int notificationId = Integer.parseInt(request.getParameter("id"));
            notificationDAO.markAsRead(notificationId);
        }
        doGet(request, response);
    }
} 