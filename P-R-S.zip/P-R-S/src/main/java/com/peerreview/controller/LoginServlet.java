package com.peerreview.controller;

import java.io.IOException;
import java.util.logging.Logger;

import javax.servlet.ServletException;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.HttpSession;

import com.peerreview.dao.UserDAO;
import com.peerreview.model.User;

public class LoginServlet extends HttpServlet {
    private static final Logger LOGGER = Logger.getLogger(LoginServlet.class.getName());
    private UserDAO userDAO;

    @Override
    public void init() throws ServletException {
        userDAO = new UserDAO();
        LOGGER.info("LoginServlet initialized");
    }

    @Override
    protected void doGet(HttpServletRequest request, HttpServletResponse response) 
            throws ServletException, IOException {
        HttpSession session = request.getSession(false);
        if (session != null && session.getAttribute("user") != null) {
            LOGGER.info("User already logged in, redirecting to dashboard");
            redirectToDashboard(request, response, (User) session.getAttribute("user"));
        } else {
            LOGGER.info("Showing login page");
            request.getRequestDispatcher("/login.jsp").forward(request, response);
        }
    }

    @Override
    protected void doPost(HttpServletRequest request, HttpServletResponse response) 
            throws ServletException, IOException {
        String email = request.getParameter("email");
        String password = request.getParameter("password");

        LOGGER.info("Login attempt - Email: " + email + ", Password: " + password);

        // Basic validation
        if (email == null || password == null || email.trim().isEmpty() || password.trim().isEmpty()) {
            LOGGER.warning("Empty email or password submitted");
            request.setAttribute("error", "Please enter both email and password");
            request.getRequestDispatcher("/login.jsp").forward(request, response);
            return;
        }

        // Find user by email
        User user = userDAO.findByEmail(email);
        if (user != null) {
            LOGGER.info("User found - Email: " + user.getEmail() + ", Stored Password: " + user.getPassword());
            
            // Plain text password comparison
            if (password.equals(user.getPassword())) {
                LOGGER.info("Password matches for user: " + email);
                // Password matches, create session
                HttpSession session = request.getSession();
                session.setAttribute("user", user);
                session.setMaxInactiveInterval(30 * 60); // 30 minutes

                // Redirect to appropriate dashboard
                redirectToDashboard(request, response, user);
            } else {
                LOGGER.warning("Password mismatch - Input: " + password + ", Stored: " + user.getPassword());
                request.setAttribute("error", "Invalid email or password");
                request.getRequestDispatcher("/login.jsp").forward(request, response);
            }
        } else {
            LOGGER.warning("No user found with email: " + email);
            request.setAttribute("error", "Invalid email or password");
            request.getRequestDispatcher("/login.jsp").forward(request, response);
        }
    }

    private void redirectToDashboard(HttpServletRequest request, HttpServletResponse response, User user) throws IOException {
        String contextPath = request.getContextPath();
        String dashboard;
        switch (user.getRole()) {
            case Manager:
                dashboard = "/manager/dashboard";
                break;
            case DataEntry:
                dashboard = "/dataentry/dashboard";
                break;
            default:
                dashboard = "/reviewer/dashboard";
                break;
        }
        LOGGER.info("Redirecting user to dashboard: " + dashboard);
        response.sendRedirect(contextPath + dashboard);
    }
} 