package com.peerreview.controller;

import java.io.IOException;
import java.util.HashMap;
import java.util.Map;

import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.HttpSession;

import com.peerreview.dao.ReviewDAO;
import com.peerreview.dao.UserDAO;
import com.peerreview.model.Review;
import com.peerreview.model.User;
import com.peerreview.util.NotificationUtil;

@WebServlet("/reviewer/submit-kra")
public class SubmitKRAServlet extends HttpServlet {
    private ReviewDAO reviewDAO;
    private UserDAO userDAO;

    @Override
    public void init() throws ServletException {
        reviewDAO = new ReviewDAO();
        userDAO = new UserDAO();
    }

    @Override
    protected void doGet(HttpServletRequest request, HttpServletResponse response) 
            throws ServletException, IOException {
        
        HttpSession session = request.getSession(false);
        User reviewer = (User) session.getAttribute("user");
        
        // Get review ID from query parameter
        String reviewId = request.getParameter("id");
        if (reviewId == null || reviewId.trim().isEmpty()) {
            response.sendRedirect("dashboard");
            return;
        }

        // Get review details
        Review review = reviewDAO.findById(Integer.parseInt(reviewId));
        if (review == null) {
            response.sendRedirect("dashboard");
            return;
        }

        // Verify reviewer is assigned to this review
        if (!reviewDAO.isReviewerAssigned(review.getId(), reviewer.getId())) {
            response.sendRedirect("dashboard");
            return;
        }

        // Get reviewee details
        User reviewee = userDAO.findById(review.getRevieweeId());
        
        // Calculate days remaining
        long daysRemaining = reviewDAO.calculateDaysRemaining(review.getId());

        request.setAttribute("review", review);
        request.setAttribute("reviewee", reviewee);
        request.setAttribute("daysRemaining", daysRemaining);
        request.getRequestDispatcher("/WEB-INF/reviewer/kra-form.jsp").forward(request, response);
    }

    @Override
    protected void doPost(HttpServletRequest request, HttpServletResponse response) 
            throws ServletException, IOException {
        
        HttpSession session = request.getSession(false);
        User reviewer = (User) session.getAttribute("user");

        try {
            int reviewId = Integer.parseInt(request.getParameter("reviewId"));
            
            // Verify reviewer is assigned to this review
            if (!reviewDAO.isReviewerAssigned(reviewId, reviewer.getId())) {
                response.sendRedirect("dashboard");
                return;
            }

            // Get review details
            Review review = reviewDAO.findById(reviewId);
            if (review == null) {
                response.sendRedirect("dashboard");
                return;
            }

            // Create a map to store ratings and comments
            Map<String, Object> kraData = new HashMap<>();
            
            // Technical Skills
            kraData.put("technical_1", Integer.parseInt(request.getParameter("technical_1")));
            kraData.put("technical_2", Integer.parseInt(request.getParameter("technical_2")));
            kraData.put("technical_comments", request.getParameter("technical_comments"));

            // Communication Skills
            kraData.put("communication_1", Integer.parseInt(request.getParameter("communication_1")));
            kraData.put("communication_2", Integer.parseInt(request.getParameter("communication_2")));
            kraData.put("communication_comments", request.getParameter("communication_comments"));

            // Overall Comments
            kraData.put("overall_comments", request.getParameter("overall_comments"));

            // Save KRA form data
            if (reviewDAO.submitKRAForm(reviewId, reviewer.getId(), kraData)) {
                // Send notification to manager
                String message = String.format("KRA review for %s has been submitted by %s", 
                        userDAO.findById(review.getRevieweeId()).getName(),
                        reviewer.getName());
                NotificationUtil.sendNotification(reviewer.getId(), review.getManagerId(), message);

                // Check if all reviewers have submitted
                if (reviewDAO.haveAllReviewersSubmitted(reviewId)) {
                    // Update review status to Completed
                    reviewDAO.updateReviewStatus(reviewId, Review.ReviewStatus.Completed);
                    
                    // Notify manager that all reviews are in
                    message = String.format("All reviews have been submitted for %s's KRA review", 
                            userDAO.findById(review.getRevieweeId()).getName());
                    NotificationUtil.sendNotification(reviewer.getId(), review.getManagerId(), message);
                }

                response.sendRedirect("dashboard?success=Review submitted successfully");
            } else {
                request.setAttribute("error", "Failed to submit review. Please try again.");
                doGet(request, response);
            }

        } catch (Exception e) {
            request.setAttribute("error", "An error occurred while submitting the review.");
            doGet(request, response);
        }
    }
} 