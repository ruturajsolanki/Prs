package com.peerreview.controller;

import java.io.IOException;
import java.util.List;
import java.util.Map;

import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.HttpSession;

import com.peerreview.dao.ReviewDAO;
import com.peerreview.dao.ThoughtDAO;
import com.peerreview.model.Review;
import com.peerreview.model.User;

@WebServlet("/reviewer/dashboard")
public class ReviewerDashboardServlet extends HttpServlet {
    private ReviewDAO reviewDAO;
    private ThoughtDAO thoughtDAO;

    @Override
    public void init() throws ServletException {
        reviewDAO = new ReviewDAO();
        thoughtDAO = new ThoughtDAO();
    }

    @Override
    protected void doGet(HttpServletRequest request, HttpServletResponse response) 
            throws ServletException, IOException {
        
        HttpSession session = request.getSession(false);
        User reviewer = (User) session.getAttribute("user");

        // Get review statistics
        int totalReviews = reviewDAO.countTotalReviewsByReviewer(reviewer.getId());
        int pendingReviews = reviewDAO.countPendingReviewsByReviewer(reviewer.getId());
        int completedReviews = reviewDAO.countCompletedReviewsByReviewer(reviewer.getId());

        // Get assigned reviews
        List<Review> assignedReviews = reviewDAO.findAssignedReviews(reviewer.getId());

        // Get recent activity
        List<Map<String, String>> recentActivity = reviewDAO.getRecentActivityByReviewer(reviewer.getId(), 5);

        // Get thought of the day
        String thoughtOfTheDay = thoughtDAO.getThoughtOfTheDay();

        // Set attributes for JSP
        request.setAttribute("totalReviews", totalReviews);
        request.setAttribute("pendingReviews", pendingReviews);
        request.setAttribute("completedReviews", completedReviews);
        request.setAttribute("assignedReviews", assignedReviews);
        request.setAttribute("recentActivity", recentActivity);
        request.setAttribute("thoughtOfTheDay", thoughtOfTheDay);

        // Forward to dashboard JSP
        request.getRequestDispatcher("/WEB-INF/reviewer/dashboard.jsp").forward(request, response);
    }
} 