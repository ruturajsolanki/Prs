package com.peerreview.controller;

import java.io.IOException;
import java.util.HashMap;
import java.util.Map;

import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.HttpSession;

import com.peerreview.dao.ReviewDAO;
import com.peerreview.dao.UserDAO;
import com.peerreview.model.Review;
import com.peerreview.model.User;
import com.peerreview.util.NotificationUtil;

@WebServlet("/reviewer/submit-feedback")
public class SubmitFeedbackServlet extends HttpServlet {
    private ReviewDAO reviewDAO;
    private UserDAO userDAO;

    @Override
    public void init() throws ServletException {
        reviewDAO = new ReviewDAO();
        userDAO = new UserDAO();
    }

    @Override
    protected void doGet(HttpServletRequest request, HttpServletResponse response) 
            throws ServletException, IOException {
        
        HttpSession session = request.getSession(false);
        User reviewer = (User) session.getAttribute("user");
        
        // Get review ID from query parameter
        String reviewId = request.getParameter("id");
        if (reviewId == null || reviewId.trim().isEmpty()) {
            response.sendRedirect("dashboard");
            return;
        }

        // Get review details
        Review review = reviewDAO.findById(Integer.parseInt(reviewId));
        if (review == null || review.getType() != Review.ReviewType.Feedback) {
            response.sendRedirect("dashboard");
            return;
        }

        // Verify reviewer is assigned to this review
        if (!reviewDAO.isReviewerAssigned(review.getId(), reviewer.getId())) {
            response.sendRedirect("dashboard");
            return;
        }

        // Get reviewee details
        User reviewee = userDAO.findById(review.getRevieweeId());
        
        // Calculate days remaining
        long daysRemaining = reviewDAO.calculateDaysRemaining(review.getId());

        request.setAttribute("review", review);
        request.setAttribute("reviewee", reviewee);
        request.setAttribute("daysRemaining", daysRemaining);
        request.getRequestDispatcher("/WEB-INF/reviewer/feedback-form.jsp").forward(request, response);
    }

    @Override
    protected void doPost(HttpServletRequest request, HttpServletResponse response) 
            throws ServletException, IOException {
        
        HttpSession session = request.getSession(false);
        User reviewer = (User) session.getAttribute("user");

        try {
            int reviewId = Integer.parseInt(request.getParameter("reviewId"));
            
            // Verify reviewer is assigned to this review
            if (!reviewDAO.isReviewerAssigned(reviewId, reviewer.getId())) {
                response.sendRedirect("dashboard");
                return;
            }

            // Get review details
            Review review = reviewDAO.findById(reviewId);
            if (review == null || review.getType() != Review.ReviewType.Feedback) {
                response.sendRedirect("dashboard");
                return;
            }

            // Create a map to store feedback data
            Map<String, String> feedbackData = new HashMap<>();
            feedbackData.put("strengths", request.getParameter("strengths"));
            feedbackData.put("improvements", request.getParameter("improvements"));
            feedbackData.put("additional_comments", request.getParameter("additional_comments"));

            // Save feedback form data
            if (reviewDAO.submitFeedbackForm(reviewId, reviewer.getId(), feedbackData)) {
                // Send notification to manager
                String message = String.format("Feedback review for %s has been submitted by %s", 
                        userDAO.findById(review.getRevieweeId()).getName(),
                        reviewer.getName());
                NotificationUtil.sendNotification(reviewer.getId(), review.getManagerId(), message);

                // Check if all reviewers have submitted
                if (reviewDAO.haveAllReviewersSubmitted(reviewId)) {
                    // Update review status to Completed
                    reviewDAO.updateReviewStatus(reviewId, Review.ReviewStatus.Completed);
                    
                    // Notify manager that all reviews are in
                    message = String.format("All reviews have been submitted for %s's feedback review", 
                            userDAO.findById(review.getRevieweeId()).getName());
                    NotificationUtil.sendNotification(reviewer.getId(), review.getManagerId(), message);
                }

                response.sendRedirect("dashboard?success=Feedback submitted successfully");
            } else {
                request.setAttribute("error", "Failed to submit feedback. Please try again.");
                doGet(request, response);
            }

        } catch (Exception e) {
            request.setAttribute("error", "An error occurred while submitting the feedback.");
            doGet(request, response);
        }
    }
} 