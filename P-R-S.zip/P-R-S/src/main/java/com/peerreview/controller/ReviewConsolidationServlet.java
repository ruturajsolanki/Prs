package com.peerreview.controller;

import java.io.IOException;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.HttpSession;

import com.google.gson.Gson;
import com.peerreview.dao.ReviewDAO;
import com.peerreview.dao.UserDAO;
import com.peerreview.model.User;

@WebServlet("/manager/review-consolidation")
public class ReviewConsolidationServlet extends HttpServlet {
    private ReviewDAO reviewDAO;
    private UserDAO userDAO;
    private Gson gson;

    @Override
    public void init() throws ServletException {
        reviewDAO = new ReviewDAO();
        userDAO = new UserDAO();
        gson = new Gson();
    }

    @Override
    protected void doGet(HttpServletRequest request, HttpServletResponse response) 
            throws ServletException, IOException {
        
        HttpSession session = request.getSession(false);
        User manager = (User) session.getAttribute("user");

        // Get all employees under this manager
        List<User> employees = userDAO.findEmployeesByManager(manager.getId());
        request.setAttribute("employees", employees);

        // Get selected employee and period
        String employeeId = request.getParameter("employeeId");
        String period = request.getParameter("period");
        int months = period != null ? Integer.parseInt(period) : 12;

        if (employeeId != null && !employeeId.trim().isEmpty()) {
            User selectedEmployee = userDAO.findById(Integer.parseInt(employeeId));
            request.setAttribute("selectedEmployee", selectedEmployee);

            // Get average scores
            Map<String, Double> averageScores = reviewDAO.getAverageScores(selectedEmployee.getId(), months);
            request.setAttribute("averageScores", averageScores);

            // Get score trends (comparison with previous period)
            Map<String, Double> trends = reviewDAO.getScoreTrends(selectedEmployee.getId(), months);
            request.setAttribute("trends", trends);

            // Get review statistics
            Map<String, Integer> reviewStats = new HashMap<>();
            reviewStats.put("completed", reviewDAO.countCompletedReviewsByReviewee(selectedEmployee.getId()));
            reviewStats.put("pending", reviewDAO.countPendingReviewsByReviewee(selectedEmployee.getId()));
            request.setAttribute("reviewStats", reviewStats);

            // Get trend data for chart
            Map<String, Object> trendData = reviewDAO.getPerformanceTrendData(selectedEmployee.getId(), months);
            request.setAttribute("trendData", gson.toJson(trendData));

            // Get recent feedback
            List<Map<String, Object>> recentFeedback = reviewDAO.getRecentFeedback(selectedEmployee.getId(), months);
            request.setAttribute("recentFeedback", recentFeedback);
        }

        request.getRequestDispatcher("/WEB-INF/manager/review-consolidation.jsp").forward(request, response);
    }
} 