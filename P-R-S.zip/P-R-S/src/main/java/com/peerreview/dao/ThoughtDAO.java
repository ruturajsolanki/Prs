package com.peerreview.dao;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;
import java.util.logging.Level;
import java.util.logging.Logger;

import com.peerreview.util.DBConnection;

public class ThoughtDAO {
    private static final Logger LOGGER = Logger.getLogger(ThoughtDAO.class.getName());

    public String getThoughtOfTheDay() {
        String sql = "SELECT message FROM thoughts WHERE DATE(date) = CURRENT_DATE LIMIT 1";
        try (Connection conn = DBConnection.getConnection();
             Statement stmt = conn.createStatement();
             ResultSet rs = stmt.executeQuery(sql)) {
            
            if (rs.next()) {
                return rs.getString("message");
            } else {
                // If no thought for today, get a random one
                return getRandomThought();
            }
        } catch (SQLException e) {
            LOGGER.log(Level.SEVERE, "Error getting thought of the day", e);
            return "Believe in yourself and strive for excellence!"; // Default thought
        }
    }

    private String getRandomThought() {
        String sql = "SELECT message FROM thoughts ORDER BY RAND() LIMIT 1";
        try (Connection conn = DBConnection.getConnection();
             Statement stmt = conn.createStatement();
             ResultSet rs = stmt.executeQuery(sql)) {
            
            if (rs.next()) {
                return rs.getString("message");
            }
        } catch (SQLException e) {
            LOGGER.log(Level.SEVERE, "Error getting random thought", e);
        }
        return "Every day is a new opportunity to grow!"; // Default thought
    }

    public boolean addThought(String message) {
        String sql = "INSERT INTO thoughts (message, date) VALUES (?, CURRENT_DATE)";
        try (Connection conn = DBConnection.getConnection();
             PreparedStatement stmt = conn.prepareStatement(sql)) {
            
            stmt.setString(1, message);
            return stmt.executeUpdate() > 0;
        } catch (SQLException e) {
            LOGGER.log(Level.SEVERE, "Error adding thought", e);
            return false;
        }
    }
} 